package com.example.redflags.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Resolves the lead image of an English Wikipedia article (images are hosted on Wikimedia Commons). */
object WikiImages {
    private val cache = HashMap<String, String?>()

    fun pageUrl(title: String) =
        "https://en.wikipedia.org/wiki/" + URLEncoder.encode(title.replace(' ', '_'), "UTF-8")

    suspend fun leadImage(title: String): String? = withContext(Dispatchers.IO) {
        if (cache.containsKey(title)) return@withContext cache[title]
        val result = try {
            val api = "https://en.wikipedia.org/api/rest_v1/page/summary/" +
                URLEncoder.encode(title.replace(' ', '_'), "UTF-8")
            val conn = URL(api).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "RedFlagsApp/1.0 (educational reference)")
            if (conn.responseCode == 200) {
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                json.optJSONObject("thumbnail")?.optString("source")?.takeIf { it.isNotBlank() }
            } else null
        } catch (e: Exception) { null }
        cache[title] = result
        result
    }
}
