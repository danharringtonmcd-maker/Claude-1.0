package com.example.redflags

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import android.os.Build
import androidx.compose.ui.platform.LocalContext
import com.example.redflags.data.ALL_CONDITIONS
import com.example.redflags.ui.DetailScreen
import com.example.redflags.ui.HomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RedFlagsTheme { AppRoot() } }
    }
}

@Composable
fun AppRoot() {
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val selected = ALL_CONDITIONS.firstOrNull { it.id == selectedId }
    if (selected == null) {
        HomeScreen(onOpen = { selectedId = it.id })
    } else {
        BackHandler { selectedId = null }
        DetailScreen(selected, onBack = { selectedId = null })
    }
}

@Composable
fun RedFlagsTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
