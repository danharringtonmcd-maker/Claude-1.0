package com.example.redflags.data

enum class BodySystem(val label: String) {
    CARDIOVASCULAR("Cardiovascular"),
    NEUROLOGICAL("Neurological"),
    RESPIRATORY("Respiratory"),
    GASTROINTESTINAL("Gastrointestinal"),
    INFECTION_IMMUNE("Infection & Immune"),
    ENDOCRINE("Endocrine & Metabolic"),
    RENAL("Renal & Electrolytes"),
    REPRODUCTIVE("Reproductive & Urological"),
    SPINAL("Spinal")
}

data class Condition(
    val id: String,
    val name: String,
    val system: BodySystem,
    /** Exact English Wikipedia article title, used to fetch the open-licensed lead image. */
    val wikiTitle: String,
    val summary: String,
    val signs: List<String>,
    val redFlags: List<String>,
    val prehospital: List<String>,
    val hospital: List<String>
)
