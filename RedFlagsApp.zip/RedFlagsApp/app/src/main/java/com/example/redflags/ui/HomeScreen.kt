package com.example.redflags.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.redflags.data.ALL_CONDITIONS
import com.example.redflags.data.BodySystem
import com.example.redflags.data.Condition

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpen: (Condition) -> Unit) {
    var query by remember { mutableStateOf("") }
    var system by remember { mutableStateOf<BodySystem?>(null) }

    val filtered = ALL_CONDITIONS.filter { c ->
        (system == null || c.system == system) &&
            (query.isBlank() || c.name.contains(query, true) ||
                c.signs.any { it.contains(query, true) } || c.summary.contains(query, true))
    }
    val grouped = filtered.groupBy { it.system }

    Scaffold(topBar = { TopAppBar(title = { Text("Red Flags: Emergency Reference") }) }) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    placeholder = { Text("Search condition or symptom") },
                    singleLine = true
                )
            }
            item {
                Row(
                    Modifier.fillMaxWidth().horizontalScrollCompat(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(system == null, { system = null }, label = { Text("All") })
                    BodySystem.values().forEach { s ->
                        FilterChip(system == s, { system = if (system == s) null else s }, label = { Text(s.label) })
                    }
                }
            }
            item { DisclaimerCard() }
            grouped.forEach { (sys, list) ->
                item(key = "h_${sys.name}") {
                    Text(
                        sys.label, style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                    HorizontalDivider()
                }
                items(list, key = { it.id }) { c ->
                    ListItem(
                        headlineContent = { Text(c.name) },
                        supportingContent = { Text(c.summary, maxLines = 2) },
                        trailingContent = { Icon(Icons.Default.ChevronRight, null) },
                        modifier = Modifier.clickable { onOpen(c) }
                    )
                }
            }
            if (filtered.isEmpty()) item { Text("No matches.", Modifier.padding(24.dp)) }
        }
    }
}

@Composable
fun DisclaimerCard() {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Text(
            "Educational reference only. Not a substitute for clinical judgement, training or local protocols. " +
                "In an emergency call your local emergency number.",
            Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onErrorContainer
        )
    }
}
