package com.example.redflags.data

import com.example.redflags.data.BodySystem.*

/**
 * Educational summaries only. Protocols differ by country/service (JRCALC, AHA/ACLS, ERC, local CPGs).
 * Doses are deliberately omitted: always follow your local protocol and formulary.
 */
val ALL_CONDITIONS: List<Condition> = listOf(

    // ---------------- CARDIOVASCULAR ----------------
    Condition(
        "acs", "Acute Coronary Syndrome / Heart Attack", CARDIOVASCULAR, "Myocardial infarction",
        "Reduced blood flow to heart muscle from a blocked coronary artery. Time-critical: muscle is lost every minute.",
        listOf("Central/left chest pain, pressure or tightness, may radiate to arm, jaw or back",
            "Sweating, nausea, breathlessness", "Pale, clammy, anxious ('sense of doom')",
            "Atypical in women, elderly and diabetics: fatigue, epigastric pain, dyspnoea only"),
        listOf("ST elevation or new LBBB on 12-lead", "Hypotension, arrhythmia or syncope", "Pain >15–20 min unrelieved by rest"),
        listOf("Rest, ABCDE, 12-lead ECG early and pre-alert the PCI centre if STEMI",
            "Aspirin (chewed) unless allergic", "Oxygen only if SpO2 below target (~94%)",
            "Analgesia per protocol; GTN if BP adequate and no RV infarct/PDE5 inhibitor use",
            "IV access, monitor, defibrillator pads ready", "Transport to PCI-capable centre"),
        listOf("Serial ECG and troponin", "Primary PCI for STEMI (or fibrinolysis if PCI delayed)",
            "Dual antiplatelets, anticoagulation, statin, beta-blocker", "Cardiac monitoring in CCU; echo; secondary prevention")
    ),
    Condition(
        "ccf", "Congestive Cardiac Failure (Acute Pulmonary Oedema)", CARDIOVASCULAR, "Heart failure",
        "Heart cannot pump enough blood; fluid backs up into lungs and tissues.",
        listOf("Breathlessness, orthopnoea, paroxysmal nocturnal dyspnoea", "Frothy pink sputum, crackles throughout lungs",
            "Raised JVP, peripheral oedema, weight gain", "Tachycardia, cool peripheries, fatigue"),
        listOf("SpO2 <90% or exhaustion", "Hypotension or cardiogenic shock", "Chest pain suggesting ACS trigger"),
        listOf("Sit upright, ABCDE, titrated oxygen to target", "CPAP if available and trained",
            "GTN if systolic BP adequate", "Diuretic per local protocol", "12-lead ECG, monitor, IV access"),
        listOf("IV loop diuretic, nitrates if hypertensive", "Non-invasive ventilation", "Treat precipitant (ACS, arrhythmia, infection)",
            "Echo, BNP, renal function; start/optimise HF therapy", "Inotropes/ICU for cardiogenic shock")
    ),
    Condition(
        "dissection", "Aortic Dissection", CARDIOVASCULAR, "Aortic dissection",
        "Tear in the aortic wall creating a false lumen. High early mortality.",
        listOf("Sudden severe 'tearing' chest or back pain", "Pulse or BP difference between arms",
            "Syncope, neurological deficit, limb ischaemia", "Hypertension (or shock if ruptured)"),
        listOf("Pain maximal at onset", "Widened mediastinum on CXR", "Known Marfan/connective tissue disease, hypertension"),
        listOf("Treat as time-critical: ABCDE, minimal movement", "Bilateral arm BPs", "Analgesia per protocol",
            "Avoid thrombolytics/anticoagulants if dissection suspected", "Pre-alert to vascular/cardiothoracic centre"),
        listOf("CT angiography aorta", "IV beta-blocker then vasodilator to lower HR and BP", "Type A: emergency surgery",
            "Type B: medical management ± endovascular stent", "ICU monitoring")
    ),
    Condition(
        "aaa", "Ruptured Abdominal Aortic Aneurysm", CARDIOVASCULAR, "Abdominal aortic aneurysm",
        "Leaking or ruptured dilated abdominal aorta. Often mistaken for renal colic.",
        listOf("Sudden abdominal, flank or back pain", "Collapse or syncope", "Pulsatile abdominal mass",
            "Shock: pale, sweaty, tachycardic, hypotensive"),
        listOf("Age >65, male, smoker, known AAA", "'Renal colic' in an older patient", "Profound hypotension"),
        listOf("Immediate pre-alert to vascular centre", "Permissive hypotension: do not over-fill",
            "Large-bore access, minimal fluids, blood if available", "Keep warm, move gently, rapid transport"),
        listOf("Immediate surgical review", "CT angiography if stable enough", "Emergency open repair or EVAR",
            "Massive transfusion protocol, tranexamic acid per policy", "ICU post-op")
    ),

    // ---------------- NEUROLOGICAL ----------------
    Condition(
        "stroke", "Stroke / TIA", NEUROLOGICAL, "Stroke",
        "Interruption of blood supply to the brain (ischaemic) or bleeding (haemorrhagic).",
        listOf("FAST: Face droop, Arm weakness, Speech disturbance, Time to call", "Sudden vision loss, vertigo, imbalance",
            "Severe sudden headache (haemorrhage)", "Confusion, reduced consciousness"),
        listOf("Onset time (or last seen well) is critical", "Anticoagulant use", "Seizure at onset or GCS drop"),
        listOf("ABCDE, check blood glucose to exclude hypoglycaemia", "Stroke scale (FAST/BE-FAST/ROSIER)",
            "Record last-known-well time", "Oxygen only if hypoxic; keep nil by mouth",
            "Pre-alert hyperacute stroke unit; do not delay for BP lowering"),
        listOf("Urgent CT/CT angiography (± perfusion)", "Thrombolysis within window if eligible", "Thrombectomy for large vessel occlusion",
            "Haemorrhage: BP control, reverse anticoagulation, neurosurgery", "Stroke unit care, swallow screen, antiplatelet, rehab")
    ),
    Condition(
        "sah", "Subarachnoid Haemorrhage", NEUROLOGICAL, "Subarachnoid hemorrhage",
        "Bleeding into the subarachnoid space, usually from a ruptured aneurysm.",
        listOf("Sudden 'thunderclap' worst-ever headache", "Neck stiffness, photophobia", "Vomiting, collapse, seizure", "Reduced consciousness"),
        listOf("Peak intensity within seconds to minutes", "Focal deficit or falling GCS", "Sentinel headache days earlier"),
        listOf("ABCDE, protect airway, GCS and pupils", "Check glucose", "Antiemetic and analgesia per protocol",
            "Keep calm, head up 30° if safe", "Pre-alert neurosurgical centre"),
        listOf("Non-contrast CT head ± lumbar puncture/CTA", "Neurosurgical or endovascular aneurysm securing",
            "Nimodipine to reduce vasospasm", "BP control, ICU/neuro-ICU monitoring", "Treat hydrocephalus (EVD)")
    ),
    Condition(
        "meningitis", "Bacterial Meningitis / Meningococcal Disease", NEUROLOGICAL, "Meningitis",
        "Infection of the meninges, often with septicaemia. Can kill within hours.",
        listOf("Fever, severe headache, neck stiffness, photophobia", "Non-blanching petechial or purpuric rash",
            "Vomiting, drowsiness, confusion, seizures", "Infants: bulging fontanelle, high-pitched cry, poor feeding"),
        listOf("Non-blanching rash (glass test)", "Shock or reduced GCS", "Rapid deterioration"),
        listOf("Isolate/use droplet precautions", "ABCDE, treat as sepsis", "Give parenteral antibiotics early if local protocol allows",
            "IV/IO fluids for shock", "Pre-alert; transfer urgently"),
        listOf("Blood cultures, then immediate IV antibiotics ± dexamethasone", "CT before LP only if indicated", "LP for CSF analysis",
            "Public health notification and contact prophylaxis", "ICU if septic shock")
    ),
    Condition(
        "status", "Status Epilepticus", NEUROLOGICAL, "Status epilepticus",
        "Seizure lasting >5 minutes or repeated seizures without recovery.",
        listOf("Prolonged generalised convulsions", "Unresponsive between seizures", "Cyanosis, frothing, incontinence", "Subtle: twitching, eye deviation"),
        listOf("Seizure >5 min", "Hypoxia or hypoglycaemia", "Head injury, overdose or pregnancy (eclampsia)"),
        listOf("Protect from injury, time the seizure, nothing in the mouth", "Airway support, high-flow oxygen once seizing",
            "Check blood glucose", "Benzodiazepine per protocol (buccal/IM/IV/rectal)", "Transport if ongoing or first seizure"),
        listOf("Repeat benzodiazepine then second-line anticonvulsant (levetiracetam, valproate or phenytoin)", "Treat cause: glucose, electrolytes, toxicology, CT",
            "Refractory: anaesthesia and ICU with EEG", "Eclampsia: magnesium sulphate")
    ),

    // ---------------- RESPIRATORY ----------------
    Condition(
        "copd", "COPD Exacerbation", RESPIRATORY, "Chronic obstructive pulmonary disease",
        "Acute worsening of cough, sputum and breathlessness in chronic lung disease.",
        listOf("Increased breathlessness, wheeze", "Increased or purulent sputum", "Accessory muscle use, pursed-lip breathing",
            "Confusion or drowsiness from CO2 retention"),
        listOf("Drowsy, exhausted, silent chest", "SpO2 falling despite treatment", "Cyanosis or rising CO2"),
        listOf("Controlled oxygen: target SpO2 88–92% (use alert card if present)", "Nebulised bronchodilators, driven by air if CO2 retainer",
            "Corticosteroid per protocol", "Sit upright, monitor, 12-lead", "CPAP/NIV if trained; transport"),
        listOf("ABG, CXR, ECG", "Nebulisers, oral steroids, antibiotics if infective", "NIV for respiratory acidosis",
            "Intubation/ICU if failing NIV", "Early respiratory team and discharge planning")
    ),
    Condition(
        "pe", "Pulmonary Embolism", RESPIRATORY, "Pulmonary embolism",
        "Blood clot lodged in the pulmonary arteries, usually from leg veins.",
        listOf("Sudden breathlessness, pleuritic chest pain", "Haemoptysis, tachycardia, tachypnoea", "Unilateral leg swelling or pain",
            "Syncope or collapse in massive PE"),
        listOf("Hypotension or cardiac arrest", "Recent surgery, immobility, cancer, pregnancy, long travel", "Hypoxia with clear chest"),
        listOf("ABCDE, oxygen to target SpO2", "12-lead ECG (tachycardia, S1Q3T3, RV strain)", "IV access; monitor",
            "Do not delay transport; pre-alert if unstable"),
        listOf("Wells score, D-dimer, CT pulmonary angiogram", "Therapeutic anticoagulation (LMWH/DOAC)",
            "Massive PE: thrombolysis or thrombectomy", "ECHO, long-term anticoagulation planning")
    ),
    Condition(
        "asthma", "Acute Severe / Life-threatening Asthma", RESPIRATORY, "Asthma",
        "Airway inflammation and bronchospasm causing severe obstruction.",
        listOf("Wheeze, cough, tight chest", "Unable to complete sentences", "Accessory muscle use, tachycardia",
            "Late: silent chest, cyanosis, exhaustion, confusion"),
        listOf("Peak flow <33% predicted", "Silent chest or bradycardia", "Previous ICU admission for asthma"),
        listOf("High-flow oxygen, sit upright", "Nebulised salbutamol ± ipratropium, repeat", "Corticosteroid",
            "IM adrenaline if anaphylaxis suspected", "Early pre-alert; do not leave unaccompanied"),
        listOf("Back-to-back bronchodilators, steroids, IV magnesium", "ABG, CXR to exclude pneumothorax",
            "Aminophylline/IV salbutamol in refractory cases", "ICU and ventilation if failing")
    ),
    Condition(
        "tension", "Tension Pneumothorax", RESPIRATORY, "Pneumothorax",
        "Air trapped in the pleural space under pressure, compressing the lung and heart.",
        listOf("Severe respiratory distress", "Absent breath sounds, hyper-resonance on one side", "Tracheal deviation (late)",
            "Distended neck veins, hypotension, tachycardia"),
        listOf("Trauma or ventilated patient deteriorating", "Rapid shock with chest signs", "Cardiac arrest (PEA) in trauma"),
        listOf("Diagnose clinically: do not wait for imaging", "High-flow oxygen", "Needle or finger decompression per protocol (lateral 4th/5th intercostal space)",
            "Treat as time-critical trauma; transport"),
        listOf("Chest drain insertion (finger thoracostomy then tube)", "CXR after decompression", "Analgesia, monitoring",
            "Surgical referral if persistent air leak")
    ),

    // ---------------- GASTROINTESTINAL ----------------
    Condition(
        "gallstones", "Gallstone Disease / Acute Cholecystitis", GASTROINTESTINAL, "Cholecystitis",
        "Gallstones obstructing the biliary tree causing colic, inflammation, or infection (cholangitis).",
        listOf("Right upper quadrant or epigastric pain, post-fatty meal", "Nausea, vomiting", "Murphy's sign, fever",
            "Jaundice, dark urine, pale stools"),
        listOf("Charcot's triad: fever, jaundice, RUQ pain (cholangitis)", "Hypotension or confusion (septic)", "Persistent pain >6 hours"),
        listOf("ABCDE, analgesia and antiemetic per protocol", "Fluids if dehydrated", "Treat as sepsis if febrile and unwell",
            "Transport to ED/surgical unit"),
        listOf("Bloods (LFTs, lipase, CRP, cultures), ultrasound", "IV fluids, analgesia, antibiotics", "Laparoscopic cholecystectomy (early)",
            "ERCP for bile duct stones/cholangitis")
    ),
    Condition(
        "pancreatitis", "Acute Pancreatitis", GASTROINTESTINAL, "Pancreatitis",
        "Inflammation of the pancreas, commonly from gallstones or alcohol.",
        listOf("Severe epigastric pain radiating to back", "Relief on leaning forward", "Nausea, persistent vomiting",
            "Tachycardia, fever, abdominal tenderness"),
        listOf("Hypotension or organ failure", "Grey Turner / Cullen sign (haemorrhagic)", "Hypoxia or oliguria"),
        listOf("ABCDE, IV access and fluids", "Strong analgesia and antiemetic per protocol", "Monitor for shock", "Nil by mouth; transport to ED"),
        listOf("Serum lipase/amylase, calcium, CRP, gases", "Aggressive but guided IV fluids, analgesia, early feeding", "Ultrasound/CT for cause and complications",
            "ERCP if gallstone cholangitis", "HDU/ICU for severe disease")
    ),
    Condition(
        "obstruction", "Bowel Obstruction", GASTROINTESTINAL, "Bowel obstruction",
        "Mechanical blockage of the small or large bowel (adhesions, hernia, tumour, volvulus).",
        listOf("Colicky abdominal pain", "Vomiting (early in high obstruction; faeculent if late)", "Abdominal distension",
            "Absolute constipation: no faeces or flatus"),
        listOf("Peritonism, fever or tachycardia (strangulation or perforation)", "Irreducible painful hernia", "Previous abdominal surgery"),
        listOf("ABCDE, IV access, fluids", "Analgesia and antiemetic per protocol", "Nil by mouth", "Transport to surgical-capable ED"),
        listOf("'Drip and suck': IV fluids, NG tube decompression, electrolytes", "Abdominal X-ray / CT", "Urgent surgery if ischaemia or perforation",
            "Conservative trial for adhesional SBO")
    ),
    Condition(
        "gib", "Upper GI Bleed", GASTROINTESTINAL, "Gastrointestinal bleeding",
        "Bleeding from oesophagus, stomach or duodenum (ulcer, varices).",
        listOf("Haematemesis (fresh or coffee-ground)", "Melaena (black, tarry stool)", "Dizziness, pallor, tachycardia", "Signs of liver disease in variceal bleeds"),
        listOf("Hypotension or syncope", "Known cirrhosis or on anticoagulants", "Massive haematemesis"),
        listOf("ABCDE, protect airway", "Two large-bore IVs", "Cautious fluids/blood to maintain perfusion", "Pre-alert; rapid transport"),
        listOf("Resuscitation, transfusion, correct coagulopathy", "IV PPI; terlipressin and antibiotics for varices", "Urgent endoscopy with therapy",
            "Interventional radiology/surgery if uncontrolled")
    ),
    Condition(
        "appendicitis", "Appendicitis / Peritonitis", GASTROINTESTINAL, "Appendicitis",
        "Inflamed or perforated appendix leading to localised or generalised peritonitis.",
        listOf("Central abdominal pain migrating to right iliac fossa", "Anorexia, nausea, low-grade fever", "Rebound and guarding",
            "Pain on movement or coughing"),
        listOf("Rigid abdomen", "Tachycardia and hypotension", "Elderly, pregnant or immunosuppressed (atypical)"),
        listOf("ABCDE, IV access, analgesia and antiemetic", "Fluids if unwell", "Nil by mouth", "Transport to surgical unit"),
        listOf("Bloods, urinalysis, pregnancy test, ultrasound/CT", "IV antibiotics", "Laparoscopic appendicectomy",
            "Drain/abscess management if perforated")
    ),

    // ---------------- INFECTION & IMMUNE ----------------
    Condition(
        "sepsis", "Sepsis / Septic Shock", INFECTION_IMMUNE, "Sepsis",
        "Life-threatening organ dysfunction caused by a dysregulated response to infection.",
        listOf("Fever or hypothermia, rigors", "Tachycardia, tachypnoea", "Confusion or reduced consciousness",
            "Low BP, mottled skin, reduced urine output"),
        listOf("Systolic BP <90 or drop >40", "New confusion (GCS drop)", "Lactate >2, respiratory rate ≥22 (qSOFA)"),
        listOf("Recognise: use NEWS2/qSOFA, ask 'could this be sepsis?'", "High-flow oxygen, IV/IO access", "Fluid bolus per protocol",
            "Pre-alert 'Red Flag Sepsis'; do not delay transport", "Give prehospital antibiotics where protocol allows"),
        listOf("Sepsis Six within 1 hour: oxygen, cultures, antibiotics, fluids, lactate, urine output", "Source control (drain, surgery, remove lines)",
            "Vasopressors if fluid-refractory", "ICU for organ support")
    ),
    Condition(
        "anaphylaxis", "Anaphylaxis", INFECTION_IMMUNE, "Anaphylaxis",
        "Severe, rapid-onset allergic reaction with airway, breathing or circulation compromise.",
        listOf("Urticaria, flushing, angio-oedema", "Stridor, wheeze, throat tightness", "Hypotension, collapse",
            "Vomiting, abdominal pain, exposure to trigger"),
        listOf("Airway swelling or hoarse voice", "Hypotension or shock", "Previous anaphylaxis"),
        listOf("Remove trigger, lie flat (or sit if breathless)", "IM adrenaline immediately into anterolateral thigh, repeat after 5 min if needed",
            "High-flow oxygen, IV fluids", "Nebulised bronchodilator for wheeze", "Always transport, even if improved (biphasic risk)"),
        listOf("Repeat IM adrenaline; adrenaline infusion if refractory", "IV fluids, antihistamine/steroid as adjuncts", "Serum tryptase",
            "Observe 6–12 hours, adrenaline auto-injector and allergy referral")
    ),

    // ---------------- ENDOCRINE ----------------
    Condition(
        "dka", "Diabetic Ketoacidosis", ENDOCRINE, "Diabetic ketoacidosis",
        "Insulin deficiency leading to hyperglycaemia, ketosis and metabolic acidosis.",
        listOf("Polyuria, polydipsia, weight loss", "Nausea, vomiting, abdominal pain", "Kussmaul breathing, acetone breath",
            "Dehydration, drowsiness, coma"),
        listOf("GCS reduced", "Systolic BP <90", "Persistent vomiting or severe acidosis"),
        listOf("ABCDE, check glucose and ketones", "IV fluid bolus per protocol", "Oxygen if hypoxic", "Pre-alert; monitor ECG and GCS"),
        listOf("Fixed-rate IV insulin infusion", "IV fluids with potassium replacement", "Hourly glucose/ketones, gases",
            "Treat trigger (infection, missed insulin)", "Prevent hypoglycaemia and cerebral oedema")
    ),
    Condition(
        "hypo", "Severe Hypoglycaemia", ENDOCRINE, "Hypoglycemia",
        "Low blood glucose causing neuroglycopenia. Easily reversible but can kill or cause brain injury.",
        listOf("Sweating, tremor, hunger, palpitations", "Confusion, aggression, slurred speech", "Seizures, unconsciousness",
            "Can mimic stroke or intoxication"),
        listOf("Glucose <4 mmol/L (72 mg/dL) symptomatic", "Unresponsive or fitting", "On insulin or sulfonylurea"),
        listOf("Check glucose in every altered patient", "Conscious: fast oral glucose then complex carbohydrate",
            "Reduced consciousness: IV glucose or IM glucagon per protocol", "Recheck at 10 minutes; transport if not recovered or on long-acting agent"),
        listOf("IV dextrose, glucagon", "Find cause (insulin, sulfonylurea, alcohol, sepsis, liver)", "Octreotide for sulfonylurea overdose",
            "Observation and diabetic review")
    ),

    // ---------------- RENAL ----------------
    Condition(
        "hyperk", "Hyperkalaemia / Acute Kidney Injury", RENAL, "Hyperkalemia",
        "High potassium, commonly from AKI or medication, causing life-threatening arrhythmias.",
        listOf("Weakness, palpitations, paraesthesia", "Reduced urine output, nausea", "Bradycardia or collapse",
            "Often asymptomatic until arrhythmia"),
        listOf("ECG: peaked T, wide QRS, loss of P waves", "Dialysis patient missing sessions", "K+ ≥6.5 mmol/L"),
        listOf("12-lead ECG and monitor", "IV access", "IV calcium for ECG changes per protocol", "Pre-alert; transport to ED"),
        listOf("IV calcium gluconate/chloride to protect the heart", "Insulin-glucose infusion, nebulised salbutamol", "Remove cause, stop K+ drugs",
            "Potassium binders, dialysis for refractory cases")
    ),

    // ---------------- REPRODUCTIVE & UROLOGICAL ----------------
    Condition(
        "ectopic", "Ruptured Ectopic Pregnancy", REPRODUCTIVE, "Ectopic pregnancy",
        "Pregnancy implanted outside the uterus, typically in a fallopian tube. A leading cause of first-trimester maternal death.",
        listOf("Lower abdominal pain, usually one-sided", "Missed period, vaginal bleeding", "Shoulder-tip pain, collapse",
            "Tachycardia and hypotension"),
        listOf("Any woman of reproductive age with abdominal pain and collapse", "Peritonism", "Shock"),
        listOf("Always consider pregnancy test", "ABCDE, large-bore IV access", "Fluids/blood cautiously for shock", "Rapid transport; pre-alert"),
        listOf("Urine/serum β-hCG, pelvic ultrasound", "Resuscitation, cross-match, anti-D if Rh negative", "Emergency laparoscopy/laparotomy",
            "Methotrexate if stable and suitable")
    ),
    Condition(
        "torsion", "Testicular Torsion", REPRODUCTIVE, "Testicular torsion",
        "Twisting of the spermatic cord cutting off testicular blood supply. Salvage falls sharply after 6 hours.",
        listOf("Sudden severe unilateral testicular pain", "Nausea and vomiting", "High-riding, horizontally lying tender testis",
            "Absent cremasteric reflex"),
        listOf("Pain onset <6–8 hours", "Adolescent or young man with lower abdominal pain", "Do not delay for imaging"),
        listOf("Analgesia, nil by mouth", "Treat as surgical emergency", "Rapid transport to urology/surgical centre"),
        listOf("Immediate urology review", "Surgical exploration with detorsion and bilateral orchidopexy", "Doppler US only if it will not delay surgery",
            "Orchidectomy if non-viable")
    ),

    // ---------------- SPINAL ----------------
    Condition(
        "cauda", "Cauda Equina Syndrome", SPINAL, "Cauda equina syndrome",
        "Compression of the lumbosacral nerve roots, risking permanent bladder, bowel and leg dysfunction.",
        listOf("Severe low back pain with bilateral leg pain or weakness", "Saddle (perineal) numbness",
            "New urinary retention or incontinence", "Loss of bowel control or sexual dysfunction"),
        listOf("Saddle anaesthesia", "Bladder or bowel changes", "Rapidly progressive weakness"),
        listOf("ABCDE and neurological exam", "Log-roll and spinal precautions if trauma", "Analgesia per protocol", "Transport to spinal-capable centre; pre-alert"),
        listOf("Emergency MRI spine", "Urgent neurosurgical decompression", "Bladder scan, analgesia",
            "Rehabilitation and long-term continence care")
    )
)

val CONDITIONS_BY_SYSTEM: Map<BodySystem, List<Condition>> =
    BodySystem.values().associateWith { s -> ALL_CONDITIONS.filter { it.system == s } }
        .filterValues { it.isNotEmpty() }
