package com.example.redflags.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.redflags.data.Condition
import com.example.redflags.data.WikiImages

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(c: Condition, onBack: () -> Unit) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(c.name, maxLines = 1) },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            AssistChip(onClick = {}, label = { Text(c.system.label) })
            ConditionImage(c)
            Text(c.summary, style = MaterialTheme.typography.bodyLarge)
            Section("Signs & symptoms", c.signs, MaterialTheme.colorScheme.surfaceVariant)
            Section("Red flags", c.redFlags, MaterialTheme.colorScheme.errorContainer)
            Section("Pre-hospital (first responders)", c.prehospital, MaterialTheme.colorScheme.secondaryContainer)
            Section("Usual in-hospital treatment", c.hospital, MaterialTheme.colorScheme.tertiaryContainer)
            DisclaimerCard()
        }
    }
}

@Composable
private fun ConditionImage(c: Condition) {
    val url by produceState<String?>(null, c.wikiTitle) { value = WikiImages.leadImage(c.wikiTitle) }
    val uri = LocalUriHandler.current
    if (url != null) {
        Column {
            AsyncImage(
                model = url, contentDescription = "Illustration for ${c.name}",
                modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp),
                contentScale = ContentScale.Fit
            )
            TextButton(onClick = { uri.openUri(WikiImages.pageUrl(c.wikiTitle)) }) {
                Text("Image: Wikipedia / Wikimedia Commons (open licence). Tap for author & licence",
                    style = MaterialTheme.typography.labelSmall)
            }
        }
    } else {
        Box(Modifier.fillMaxWidth().height(60.dp), contentAlignment = Alignment.Center) {
            Text("Image unavailable offline", style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun Section(title: String, items: List<String>, container: androidx.compose.ui.graphics.Color) {
    Card(colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            items.forEach { Text("•  $it", style = MaterialTheme.typography.bodyMedium) }
        }
    }
}
